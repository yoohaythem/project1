create
    definer = root@localhost procedure ordertotal(IN onumber int, IN taxable tinyint(1), OUT ototal decimal(8, 2))
    comment 'Obtain order total, optionally adding tax'
begin
	-- Declare variable for total
    declare total decimal(8,2);
    -- Declare tax percentage
    declare taxrate int default 6;
    
    -- Get the order total
   	select sum(item_price*quantity)
    from orderitems
    where order_num = onumber
    into total;
    
    -- is this taxable?
    if taxable then
		-- Yes, so add taxrate to the total
        select total+(total/100*taxrate) into total;
	end if;
    -- And finally, save to out variable
    select total into ototal;
end;

