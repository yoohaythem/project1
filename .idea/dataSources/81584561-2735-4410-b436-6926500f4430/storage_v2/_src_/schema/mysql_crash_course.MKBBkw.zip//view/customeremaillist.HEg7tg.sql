create view customeremaillist as
select `mysql_crash_course`.`customers`.`cust_id`    AS `cust_id`,
       `mysql_crash_course`.`customers`.`cust_name`  AS `cust_name`,
       `mysql_crash_course`.`customers`.`cust_email` AS `cust_email`
from `mysql_crash_course`.`customers`
where (`mysql_crash_course`.`customers`.`cust_email` is not null);

