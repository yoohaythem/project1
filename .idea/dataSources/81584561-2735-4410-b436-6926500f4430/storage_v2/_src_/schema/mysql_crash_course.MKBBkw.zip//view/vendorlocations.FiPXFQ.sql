create view vendorlocations as
select concat(rtrim(`mysql_crash_course`.`vendors`.`vend_name`), '(',
              rtrim(`mysql_crash_course`.`vendors`.`vend_country`), ')') AS `vend_title`
from `mysql_crash_course`.`vendors`
order by `mysql_crash_course`.`vendors`.`vend_name`;

