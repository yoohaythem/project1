create view orderitemsexpanded as
select `mysql_crash_course`.`orderitems`.`order_num`                                                   AS `order_num`,
       `mysql_crash_course`.`orderitems`.`prod_id`                                                     AS `prod_id`,
       `mysql_crash_course`.`orderitems`.`quantity`                                                    AS `quantity`,
       `mysql_crash_course`.`orderitems`.`item_price`                                                  AS `item_price`,
       (`mysql_crash_course`.`orderitems`.`quantity` *
        `mysql_crash_course`.`orderitems`.`item_price`)                                                AS `expanded_price`
from `mysql_crash_course`.`orderitems`;

