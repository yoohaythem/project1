create view productcustomers as
select `mysql_crash_course`.`customers`.`cust_name`    AS `cust_name`,
       `mysql_crash_course`.`customers`.`cust_contact` AS `cust_contact`,
       `mysql_crash_course`.`orderitems`.`prod_id`     AS `prod_id`
from `mysql_crash_course`.`customers`
         join `mysql_crash_course`.`orders`
         join `mysql_crash_course`.`orderitems`
where ((`mysql_crash_course`.`customers`.`cust_id` = `mysql_crash_course`.`orders`.`cust_id`) and
       (`mysql_crash_course`.`orderitems`.`order_num` = `mysql_crash_course`.`orders`.`order_num`));

