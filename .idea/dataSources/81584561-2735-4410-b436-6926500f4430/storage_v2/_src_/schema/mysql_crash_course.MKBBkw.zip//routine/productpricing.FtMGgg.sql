create
    definer = root@localhost procedure productpricing(OUT pl decimal(8, 2), OUT ph decimal(8, 2), OUT pa decimal(8, 2))
begin 
	select min(prod_price)
    into pl
    from products;
    select max(prod_price)
    into ph
    from products;
    select avg(prod_price)
    into pa
    from products;
end;

